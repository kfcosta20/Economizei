<?php
/*
  ARQUIVO: config/database.php
  FUNÇÃO: abrir a conexão com o banco MySQL do XAMPP.
  COMO USAR: em qualquer página que precise do banco, escreva:
      require __DIR__ . '/config/database.php';
  e depois use a variável $pdo.
*/

$host   = 'localhost';
$banco  = 'economizei';
$user   = 'root';   // usuário padrão do XAMPP
$senha  = '';       // senha padrão do XAMPP é vazia

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$banco;charset=utf8mb4",
        $user,
        $senha,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,  // mostra erro de verdade
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,        // resultado como array com nomes
        ]
    );
} catch (PDOException $e) {
    // Não mostre detalhes do erro para o visitante do site
    die('Não foi possível conectar ao banco de dados.');
}
