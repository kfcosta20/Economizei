/*
  ARQUIVO: theme.js
  FUNÇÃO: controlar o tema claro/escuro em todas as telas do site.
  TELAS ATINGIDAS: HOME, OFERTAS, FAVORITOS, PERFIL, LOGIN, CADASTRO, CONTATO.
*/

(function () {
  // Controla o tema claro/escuro e o ícone de alternância em todas as páginas.
  const STORAGE_KEY = 'tema';
  const body = document.body;
  const toggleButtons = document.querySelectorAll('.theme-toggle');

  const sunIcon = `
    <svg viewBox="0 0 24 24" aria-hidden="true" class="theme-svg">
      <g fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="4.2"></circle>
        <path d="M12 2.5v2.2M12 19.3v2.2M4.93 4.93l1.56 1.56M17.51 17.51l1.56 1.56M2.5 12h2.2M19.3 12h2.2M4.93 19.07l1.56-1.56M17.51 6.49l1.56-1.56"></path>
      </g>
    </svg>
  `;

  const moonIcon = `
    <svg viewBox="0 0 24 24" aria-hidden="true" class="theme-svg">
      <path d="M21 12.8A8.8 8.8 0 0 1 11.2 3a9 9 0 1 0 9.8 9.8Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"></path>
    </svg>
  `;

  function applyTheme(isDark) {
    body.classList.toggle('modo-escuro', isDark);

    toggleButtons.forEach((button) => {
      const icon = button.querySelector('.theme-icon');
      const nextLabel = isDark ? 'Ativar modo claro' : 'Ativar modo escuro';

      if (icon) {
        icon.innerHTML = isDark ? sunIcon : moonIcon;
      }

      button.setAttribute('aria-label', nextLabel);
      button.setAttribute('aria-pressed', String(isDark));
    });
  }

  function getInitialTheme() {
    try {
      const savedTheme = localStorage.getItem(STORAGE_KEY);
      if (savedTheme === 'escuro') return true;
      if (savedTheme === 'claro') return false;
    } catch (error) {
      // Ignora falhas ao ler localStorage.
    }

    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  }

  applyTheme(getInitialTheme());

  toggleButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const isDark = !body.classList.contains('modo-escuro');
      applyTheme(isDark);

      try {
        localStorage.setItem(STORAGE_KEY, isDark ? 'escuro' : 'claro');
      } catch (error) {
        // Ignora falhas no armazenamento local.
      }
    });
  });
})();
