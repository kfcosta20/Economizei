<?php
/*
  ARQUIVO: favoritar.php
  FUNÇÃO: recebe o clique no coração (enviado pelo favoritos.js) e
          adiciona ou remove a oferta dos favoritos do usuário logado.
  Responde em JSON, por exemplo: {"ok":true,"favorito":true}
*/
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

// 1) Precisa estar logado
if (empty($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'login' => true]);
    exit;
}

// 2) Só aceita envio de formulário (POST)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false]);
    exit;
}

require __DIR__ . '/config/database.php';

$usuarioId = (int)$_SESSION['usuario_id'];
$slug      = trim($_POST['oferta'] ?? '');

// 3) Descobre qual oferta é essa
$busca = $pdo->prepare('SELECT id FROM ofertas WHERE slug = ?');
$busca->execute([$slug]);
$ofertaId = $busca->fetchColumn();

if (!$ofertaId) {
    http_response_code(404);
    echo json_encode(['ok' => false]);
    exit;
}

// 4) Já é favorita? Então remove. Se não, adiciona.
$existe = $pdo->prepare('SELECT 1 FROM favoritos WHERE usuario_id = ? AND oferta_id = ?');
$existe->execute([$usuarioId, $ofertaId]);

if ($existe->fetchColumn()) {
    $pdo->prepare('DELETE FROM favoritos WHERE usuario_id = ? AND oferta_id = ?')
        ->execute([$usuarioId, $ofertaId]);
    $favorito = false;
} else {
    $pdo->prepare('INSERT INTO favoritos (usuario_id, oferta_id) VALUES (?, ?)')
        ->execute([$usuarioId, $ofertaId]);
    $favorito = true;
}

echo json_encode(['ok' => true, 'favorito' => $favorito]);