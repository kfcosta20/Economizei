<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Porteiro: favoritos só existem para quem fez login
if (empty($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

$title = 'Favoritos';
$activePage = 'favoritos';
$scriptFiles = ['theme.js', 'favoritos.js'];

require __DIR__ . '/config/database.php';

// Busca só as ofertas favoritas desta pessoa (as mais recentes primeiro)
$sql = "SELECT o.slug, o.titulo, o.condicao, o.pagamento,
               o.preco_antigo, o.preco_novo, o.validade, o.link_oferta,
               c.slug AS categoria, l.nome AS loja
        FROM favoritos f
        JOIN ofertas o ON o.id = f.oferta_id
        JOIN categorias c ON c.id = o.categoria_id
        JOIN lojas l ON l.id = o.loja_id
        WHERE f.usuario_id = ?
        ORDER BY f.criado_em DESC";
$busca = $pdo->prepare($sql);
$busca->execute([$_SESSION['usuario_id']]);
$ofertas = $busca->fetchAll();

// Todas aqui são favoritas, então todos os corações nascem pintados
$meusFavoritos = array_column($ofertas, 'slug');

require __DIR__ . '/includes/header.php';
?>

  <section class="pagina-titulo">
    <div class="container">
      <h1>Minhas promoções favoritas</h1>
    </div>
  </section>

  <section class="ofertas-destaque">
    <div class="container">
      <div id="lista-favoritos" class="grid-ofertas">
        <?php foreach ($ofertas as $o): ?>
          <?php include __DIR__ . '/includes/card-oferta.php'; ?>
        <?php endforeach; ?>
      </div>

      <p id="favoritos-vazio" style="display: <?= empty($ofertas) ? 'block' : 'none' ?>;">
        Você ainda não salvou nenhuma promoção. Clique no coração de uma oferta para guardá-la aqui.
      </p>
    </div>
  </section>

<?php require __DIR__ . '/includes/footer.php'; ?>