<?php
$title = 'Contato';
$activePage = 'contato';
$scriptFiles = ['theme.js'];
require __DIR__ . '/includes/header.php';
?>

  <section class="pagina-titulo">
    <div class="container">
      <h1>Fale conosco</h1>
    </div>
  </section>

  <section class="contato">
    <div class="container">
      <form class="form-contato">
        <label for="nome">Nome</label>
        <input type="text" id="nome" name="nome" placeholder="Seu nome">

        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" placeholder="seu@email.com">

        <label for="mensagem">Mensagem</label>
        <textarea id="mensagem" name="mensagem" rows="5" placeholder="Escreva sua mensagem"></textarea>

        <button type="submit" class="btn">Enviar</button>
      </form>
    </div>
  </section>

<?php require __DIR__ . '/includes/footer.php'; ?>
