(function () {
  const form = document.querySelector('.auth-form');
  const cpfInput = document.getElementById('cpf-cadastro');
  const passwordInput = document.getElementById('senha-cadastro');
  const confirmationInput = document.getElementById('confirmar-senha');
  const cpfError = document.getElementById('erro-cpf');
  const passwordError = document.getElementById('erro-senha');
  const confirmationError = document.getElementById('erro-confirmar-senha');

  if (!form || !cpfInput || !passwordInput || !confirmationInput) return;

  function setError(input, errorElement, message) {
    errorElement.textContent = message;
    input.setAttribute('aria-invalid', String(Boolean(message)));
  }

  function formatCpf(value) {
    const digits = value.replace(/\D/g, '').slice(0, 11);
    if (digits.length > 9) {
      return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9)}`;
    }
    if (digits.length > 6) {
      return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
    }
    if (digits.length > 3) {
      return `${digits.slice(0, 3)}.${digits.slice(3)}`;
    }
    return digits;
  }

  function isValidCpf(value) {
    const digits = value.replace(/\D/g, '');
    if (digits.length !== 11 || /^(\d)\1{10}$/.test(digits)) return false;

    const calculateDigit = (length) => {
      let sum = 0;
      for (let index = 0; index < length; index += 1) {
        sum += Number(digits[index]) * (length + 1 - index);
      }
      const remainder = (sum * 10) % 11;
      return remainder === 10 ? 0 : remainder;
    };

    return calculateDigit(9) === Number(digits[9])
      && calculateDigit(10) === Number(digits[10]);
  }

  function validateCpf() {
    const valid = isValidCpf(cpfInput.value);
    setError(cpfInput, cpfError, valid ? '' : 'Digite um CPF válido.');
    return valid;
  }

  function validatePasswords(showMissing = false) {
    const password = passwordInput.value;
    const confirmation = confirmationInput.value;
    const passwordsMatch = password === confirmation;
    const mismatchMessage = password && confirmation && !passwordsMatch
      ? 'As senhas não coincidem.'
      : '';

    setError(
      passwordInput,
      passwordError,
      mismatchMessage || (showMissing && !password ? 'Informe uma senha.' : '')
    );
    setError(
      confirmationInput,
      confirmationError,
      mismatchMessage || (showMissing && !confirmation ? 'Confirme sua senha.' : '')
    );
    return passwordsMatch;
  }

  cpfInput.addEventListener('input', () => {
    cpfInput.value = formatCpf(cpfInput.value);
    if (cpfInput.value.replace(/\D/g, '').length === 11) {
      validateCpf();
    } else {
      setError(cpfInput, cpfError, '');
    }
  });

  cpfInput.addEventListener('blur', () => {
    if (cpfInput.value) {
      validateCpf();
    } else {
      setError(cpfInput, cpfError, 'Informe seu CPF.');
    }
  });

  passwordInput.addEventListener('input', validatePasswords);
  confirmationInput.addEventListener('input', validatePasswords);
  passwordInput.addEventListener('blur', () => validatePasswords(true));
  confirmationInput.addEventListener('blur', () => validatePasswords(true));

  form.addEventListener('submit', (event) => {
    const validCpf = validateCpf();
    const passwordsMatch = validatePasswords();

    if (!validCpf || !passwordsMatch) {
      event.preventDefault();
      if (!validCpf) cpfInput.focus();
      else confirmationInput.focus();
    }
  });
})();
