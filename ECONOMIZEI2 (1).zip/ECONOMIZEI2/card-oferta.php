<?php
/*
  ARQUIVO: includes/card-oferta.php
  FUNÇÃO: desenha UM card de oferta. Recebe a variável $o (uma linha do banco).
          Usa a lista $meusFavoritos (se existir) para pintar o coração.
          O ícone do card muda conforme a categoria da oferta.
  USO: dentro de um foreach, escreva:
      include __DIR__ . '/includes/card-oferta.php';
*/

// Calcula o desconto em % a partir dos preços
$desconto = $o['preco_antigo'] > 0
    ? round((1 - $o['preco_novo'] / $o['preco_antigo']) * 100)
    : 0;

// Esta oferta está nos favoritos do usuário logado?
$ehFavorito = in_array($o['slug'], $meusFavoritos ?? [], true);

// Ícones por categoria: cada um é uma lista de "desenhos" (paths) SVG
$icones = [
    'audio' => [
        'M7 12V9a5 5 0 0 1 10 0v3M7 12a3 3 0 0 0-3 3v1a3 3 0 0 0 3 3h1V12H7Zm10 0a3 3 0 0 1 3 3v1a3 3 0 0 1-3 3h-1V12h1Z',
    ],
    'moda' => [
        'M3 14.5h2.5l1.2-2.2 2.3 1.2 2.3-4.2 2.4 1.5 2.3-3.1h3.8a2 2 0 0 1 2 2v7.7H3v-3.9Z',
        'M7 17.5h11',
    ],
    'casa' => [
        'M7 10h10v8a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2v-8Z',
        'M9 10V8a3 3 0 0 1 6 0v2M9 14h6',
        'M12 4V2',
    ],
    'eletronicos' => [
        'M5 6h14a1 1 0 0 1 1 1v8H4V7a1 1 0 0 1 1-1Z',
        'M2.5 18h19',
    ],
    'beleza' => [
        'M12 3l1.8 4.7 4.7 1.8-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8L12 3Z',
        'M18 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8.8-2Z',
    ],
    'esporte' => [
        'M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z',
        'M4 12h16',
        'M12 4c3 2.5 3 13.5 0 16M12 4c-3 2.5-3 13.5 0 16',
    ],
    'pet' => [
        'M7.5 8.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z',
        'M16.5 8.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z',
        'M10 5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z',
        'M14 5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z',
        'M12 11.5c-2.5 0-4.5 2.5-4.5 4.5 0 1.5 1.2 2.5 2.7 2.5 1 0 1.2-.5 1.8-.5s.8.5 1.8.5c1.5 0 2.7-1 2.7-2.5 0-2-2-4.5-4.5-4.5Z',
    ],
    'livros' => [
        'M5 5.5A1.5 1.5 0 0 1 6.5 4H19v13H6.5A1.5 1.5 0 0 0 5 18.5V5.5Z',
        'M5 18.5A1.5 1.5 0 0 0 6.5 20H19',
    ],
    // ícone padrão (sacola) para categorias sem ícone próprio
    'padrao' => [
        'M7 9V7a5 5 0 0 1 10 0v2M6 9h12l-1 10H7L6 9Z',
    ],
];
$caminhosIcone = $icones[$o['categoria']] ?? $icones['padrao'];
?>
<div class="card-oferta"
     data-id="<?= htmlspecialchars($o['slug']) ?>"
     data-categoria="<?= htmlspecialchars($o['categoria']) ?>"
     data-pagamento="<?= htmlspecialchars(strtolower($o['pagamento'])) ?>">

  <button type="button"
          class="btn-favorito<?= $ehFavorito ? ' favoritado' : '' ?>"
          aria-label="Favoritar oferta"
          aria-pressed="<?= $ehFavorito ? 'true' : 'false' ?>">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.7 4.8 13.8A4.3 4.3 0 0 1 12 7.2a4.3 4.3 0 0 1 7.2 6.6L12 20.7Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
  </button>

  <span class="tag">-<?= $desconto ?>%</span>
  <h3><?= htmlspecialchars($o['titulo']) ?></h3>

  <div class="card-icon" aria-hidden="true">
    <svg viewBox="0 0 24 24">
      <?php foreach ($caminhosIcone as $caminho): ?>
        <path d="<?= $caminho ?>" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
      <?php endforeach; ?>
    </svg>
  </div>

  <p class="loja"><?= htmlspecialchars($o['loja']) ?></p>
  <p class="condicao"><?= htmlspecialchars($o['condicao'] ?? '') ?></p>
  <p class="meta-oferta"><span>Pagamento:</span> <?= htmlspecialchars($o['pagamento']) ?></p>
  <p class="preco-antigo">R$ <?= number_format($o['preco_antigo'], 2, ',', '.') ?></p>
  <p class="preco-novo">R$ <?= number_format($o['preco_novo'], 2, ',', '.') ?></p>

  <p class="validade">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3.5v2M17 3.5v2M4.5 9.5h15M5 6.5h14a1.5 1.5 0 0 1 1.5 1.5v9A1.5 1.5 0 0 1 19 18.5H5A1.5 1.5 0 0 1 3.5 17V8A1.5 1.5 0 0 1 5 6.5Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
    <span>Válido até <?= date('d/m', strtotime($o['validade'])) ?></span>
  </p>

  <a href="<?= htmlspecialchars($o['link_oferta'] ?: '#') ?>" class="btn-outline">Ver oferta</a>
</div>