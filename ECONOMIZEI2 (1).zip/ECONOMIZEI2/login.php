<?php
// A sessão é a "memória" do servidor sobre quem está logado.
// Precisa ser iniciada ANTES de qualquer HTML.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$title = 'Login';
$activePage = 'login';
$scriptFiles = ['theme.js'];

require __DIR__ . '/config/database.php';

// Quem já está logado não precisa ver a tela de login
if (!empty($_SESSION['usuario_id'])) {
    header('Location: perfil.php');
    exit;
}

$erro = '';
$login = '';
$cadastroOk = ($_GET['cadastro'] ?? '') === 'ok';   // veio do cadastro com sucesso?

// Este bloco só roda quando o formulário é ENVIADO
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['usuario-login'] ?? '');
    $senha = $_POST['senha-login'] ?? '';

    if ($login === '' || $senha === '') {
        $erro = 'Preencha usuário e senha.';
    } else {
        // Procura a pessoa pelo usuário OU pelo e-mail
        $busca = $pdo->prepare(
            'SELECT id, nome, usuario, senha_hash FROM usuarios WHERE usuario = ? OR email = ? LIMIT 1'
        );
        $busca->execute([$login, $login]);
        $u = $busca->fetch();

        // password_verify compara a senha digitada com a senha embaralhada do banco
        if ($u && password_verify($senha, $u['senha_hash'])) {
            session_regenerate_id(true);               // gera um novo "crachá" de sessão (mais seguro)
            $_SESSION['usuario_id'] = (int)$u['id'];
            $_SESSION['usuario']    = $u['usuario'];
            $_SESSION['nome']       = $u['nome'];

            header('Location: perfil.php');
            exit;
        }

        // A mensagem é a mesma para os dois casos de propósito:
        // assim ninguém descobre quais usuários existem.
        $erro = 'Usuário ou senha inválidos.';
    }
}

require __DIR__ . '/includes/header.php';
?>

  <main class="auth-page">
    <div class="container">
      <div class="auth-card">
        <h1>Entrar</h1>
        <p>Bem-vindo de volta! Faça login para continuar.</p>

        <?php if ($cadastroOk): ?>
          <div role="status" style="background:#e8f5e9;color:#1b5e20;border-radius:12px;padding:12px 16px;margin-bottom:16px;">
            Cadastro realizado com sucesso! Faça login para entrar.
          </div>
        <?php endif; ?>

        <?php if ($erro): ?>
          <div role="alert" style="background:#fdecea;color:#b00020;border-radius:12px;padding:12px 16px;margin-bottom:16px;">
            <?= htmlspecialchars($erro) ?>
          </div>
        <?php endif; ?>

        <form class="auth-form" method="post" action="login.php">
          <label for="usuario-login">Usuário ou e-mail</label>
          <input type="text" id="usuario-login" name="usuario-login" placeholder="Digite seu usuário ou e-mail" autocomplete="username" value="<?= htmlspecialchars($login) ?>" required>

          <label for="senha-login">Senha</label>
          <input type="password" id="senha-login" name="senha-login" placeholder="Digite sua senha" autocomplete="current-password" maxlength="8" required>

          <div class="auth-row">
            <label class="checkbox-row">
              <input type="checkbox" name="lembrar">
              <span>Lembrar-me</span>
            </label>
            <a href="#" class="link-auxiliar">Esqueci a senha</a>
          </div>

          <button type="submit" class="btn btn-full">Entrar</button>
        </form>

        <p class="auth-footer">
          Ainda não tem conta? <a href="cadastro.php">Cadastre-se</a>
        </p>
      </div>
    </div>
  </main>

<?php require __DIR__ . '/includes/footer.php'; ?>