<?php
/*
  ARQUIVO: logout.php
  FUNÇÃO: sair da conta (apaga a sessão) e voltar para o login.
*/
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$_SESSION = [];   // esvazia os dados da sessão

// apaga também o cookie do navegador
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}

session_destroy();

header('Location: login.php');
exit;