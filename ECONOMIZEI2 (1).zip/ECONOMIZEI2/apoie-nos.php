<?php
$title = 'Apoie-nos';
$activePage = 'apoie-nos';
$scriptFiles = ['theme.js', 'apoie-nos.js'];
require __DIR__ . '/includes/header.php';
?>

  <main class="support-page">
    <section class="pagina-titulo">
      <div class="container">
        <h1>Apoie-nos</h1>
      </div>
    </section>

    <section class="support-content">
      <div class="container">
        <div class="support-card support-page-card">
          <div class="premium-header">
            <h3>Contribua para o projeto</h3>
            <span class="premium-badge">Ajude a crescer</span>
          </div>

          <p class="support-copy">Seu apoio ajuda a manter o ECONOMIZEI com novas melhorias, mais ofertas e uma melhor experiência para todos.</p>

          <div class="support-layout">
            <aside class="support-qr" aria-label="Resumo do apoio">
              <p>Selecione como deseja apoiar o projeto.</p>
              <div class="support-highlight">
                <span>Doação</span>
                <strong id="resumo-doacao">R$ 25</strong>
              </div>
            </aside>

            <div class="support-payment">
              <div class="payment-methods">
                <label class="payment-option active">
                  <input type="radio" name="payment-method" value="Pix" checked>
                  <span>Pix</span>
                </label>
                <label class="payment-option">
                  <input type="radio" name="payment-method" value="Crédito">
                  <span>Crédito</span>
                </label>
                <label class="payment-option">
                  <input type="radio" name="payment-method" value="Débito">
                  <span>Débito</span>
                </label>
              </div>

              <div class="quick-values">
                <button type="button" class="value-pill" data-value="10">R$ 10</button>
                <button type="button" class="value-pill active" data-value="25">R$ 25</button>
                <button type="button" class="value-pill" data-value="50">R$ 50</button>
                <button type="button" class="value-pill" data-value="100">R$ 100</button>
              </div>

              <label class="field-group">
                <span>Valor do apoio</span>
                <input id="valor-apoio" type="number" value="25" min="5" step="5" placeholder="R$ 0,00">
              </label>

              <div class="card-grid">
                <label class="field-group payment-field">
                  <span>Nome no cartão</span>
                  <input type="text" placeholder="Seu nome completo">
                </label>

                <label class="field-group payment-field">
                  <span>Número do cartão</span>
                  <input type="text" placeholder="0000 0000 0000 0000">
                </label>

                <div class="mini-grid payment-field">
                  <label class="field-group">
                    <span>Validade</span>
                    <input type="text" placeholder="MM/AA">
                  </label>

                  <label class="field-group">
                    <span>CVV</span>
                    <input type="text" placeholder="123">
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div class="support-summary">
            <div>
              <span>Resumo</span>
              <strong id="valor-total">R$ 25,00</strong>
            </div>
            <div>
              <span>Pagamento</span>
              <strong id="metodo-pagamento">Pix</strong>
            </div>
            <div class="support-actions">
              <button type="button" id="abrir-qr" class="btn btn-outline support-secondary-btn">Gerar QR Pix</button>
              <button type="button" id="copiar-codigo" class="btn btn-full support-btn">Copiar código</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <div id="pix-modal" class="pix-modal hidden" role="dialog" aria-modal="true" aria-labelledby="pix-modal-title">
    <div class="pix-modal-card">
      <button type="button" id="fechar-modal" class="close-modal" aria-label="Fechar modal">×</button>
      <div class="pix-modal-header">
        <div>
          <p class="modal-label">Pagamento via Pix</p>
          <h3 id="pix-modal-title">QR do apoio</h3>
        </div>
      </div>

      <div id="qr-code" class="qr-code-grid" aria-label="Código QR de pagamento Pix"></div>

      <div class="pix-timer-wrapper">
        <span id="pix-expira-em" class="timer-pill">expira em 10:00</span>
      </div>

      <div class="pix-code-bar">
        <label for="pix-code">Código Pix</label>
        <input id="pix-code" type="text" readonly>
      </div>

      <div class="pix-modal-footer">
        <div>
          <span>Valor</span>
          <strong id="modal-valor">R$ 25,00</strong>
        </div>
        <button type="button" id="copiar-codigo-modal" class="btn btn-full support-btn">Copiar código</button>
      </div>
    </div>
  </div>

<?php require __DIR__ . '/includes/footer.php'; ?>
