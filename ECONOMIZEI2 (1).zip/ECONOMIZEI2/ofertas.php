<?php
$title = 'Ofertas';
$activePage = 'ofertas';

require __DIR__ . '/config/database.php';

$sql = "SELECT o.slug, o.titulo, o.condicao, o.pagamento,
               o.preco_antigo, o.preco_novo, o.validade, o.link_oferta,
               c.slug AS categoria, l.nome AS loja
        FROM ofertas o
        JOIN categorias c ON c.id = o.categoria_id
        JOIN lojas l ON l.id = o.loja_id
        WHERE o.ativa = 1 AND o.validade >= CURDATE()
        ORDER BY o.criado_em DESC";
$ofertas = $pdo->query($sql)->fetchAll();

require __DIR__ . '/includes/header.php';
?>

  <section class="pagina-titulo">
    <div class="container">
      <h1>Todas as ofertas</h1>
    </div>
  </section>

  <section class="ofertas-toolbar">
    <div class="container">
      <div class="marketplace-banner">
        <div>
          <h2>Ofertas do dia selecionadas por valor</h2>
          <p>Cupons e promoções com melhor custo-benefício para você.</p>
        </div>
        <a href="#" class="btn">Ver cupons</a>
      </div>

      <div class="toolbar-inner">
        <label class="search-box" aria-label="Buscar ofertas">
          <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M16 16l5 5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
          <input type="search" id="searchOferta" placeholder="Buscar ofertas...">
        </label>

        <div class="filter-chips" aria-label="Filtrar ofertas por categoria">
          <button type="button" class="chip active" data-filter="all">Todas</button>
          <button type="button" class="chip" data-filter="eletronicos">Eletrônicos</button>
          <button type="button" class="chip" data-filter="moda">Moda</button>
          <button type="button" class="chip" data-filter="casa">Casa</button>
          <button type="button" class="chip" data-filter="beleza">Beleza</button>
          <button type="button" class="chip" data-filter="audio">Áudio</button>
          <button type="button" class="chip" data-filter="esporte">Esporte</button>
          <button type="button" class="chip" data-filter="pet">Pet</button>
          <button type="button" class="chip" data-filter="livros">Livros</button>
        </div>
      </div>
    </div>
  </section>

  <section class="ofertas-destaque">
    <div class="container">
      <div class="grid-ofertas">
       <?php foreach ($ofertas as $o): ?>
    <?php include __DIR__ . '/includes/card-oferta.php'; ?>
  <?php endforeach; ?>

  <?php if (empty($ofertas)): ?>
    <p>Nenhuma oferta disponível no momento.</p>
  <?php endif; ?>
      </div>
    </div>
  </section>

  <script>
    const searchInput = document.getElementById('searchOferta');
    const chips = document.querySelectorAll('.chip');
    const cards = document.querySelectorAll('.card-oferta');
    let activeFilter = 'all';

    function updateOffers() {
      const query = (searchInput ? searchInput.value.trim().toLowerCase() : '');

      cards.forEach((card) => {
        const text = card.textContent.toLowerCase();
        const category = card.dataset.categoria || 'all';
        const matchesFilter = activeFilter === 'all' || category === activeFilter;
        const matchesQuery = !query || text.includes(query);
        card.classList.toggle('hidden', !(matchesFilter && matchesQuery));
      });
    }

    if (searchInput) {
      searchInput.addEventListener('input', updateOffers);
    }

    chips.forEach((chip) => {
      chip.addEventListener('click', () => {
        chips.forEach((item) => item.classList.toggle('active', item === chip));
        activeFilter = chip.dataset.filter || 'all';
        updateOffers();
      });
    });

    updateOffers();
  </script>

<?php $scriptFiles = ['theme.js', 'favoritos.js']; require __DIR__ . '/includes/footer.php'; ?>
