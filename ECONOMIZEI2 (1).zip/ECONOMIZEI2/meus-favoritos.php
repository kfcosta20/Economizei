<?php
/*
  ARQUIVO: includes/meus-favoritos.php
  FUNÇÃO: cria a lista $meusFavoritos com os "slugs" das ofertas que o
          usuário logado favoritou. Os cards usam essa lista para pintar o coração.
  USO: incluir DEPOIS de require config/database.php (precisa do $pdo):
      require __DIR__ . '/includes/meus-favoritos.php';
*/
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$meusFavoritos = [];

if (!empty($_SESSION['usuario_id'])) {
    $consulta = $pdo->prepare(
        'SELECT o.slug
         FROM favoritos f
         JOIN ofertas o ON o.id = f.oferta_id
         WHERE f.usuario_id = ?'
    );
    $consulta->execute([$_SESSION['usuario_id']]);
    $meusFavoritos = $consulta->fetchAll(PDO::FETCH_COLUMN);
}