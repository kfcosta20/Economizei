<?php
$title = 'Cadastro';
$activePage = 'cadastro';
$scriptFiles = ['theme.js'];

require __DIR__ . '/config/database.php';

/*
  Confere se um CPF é verdadeiro (calcula os 2 dígitos finais).
  Recebe só números, ex: "12345678909".
*/
function cpf_valido(string $cpf): bool
{
    if (strlen($cpf) !== 11 || preg_match('/^(\d)\1{10}$/', $cpf)) {
        return false;
    }
    for ($t = 9; $t < 11; $t++) {
        $soma = 0;
        for ($i = 0; $i < $t; $i++) {
            $soma += (int)$cpf[$i] * (($t + 1) - $i);
        }
        $digito = ((10 * $soma) % 11) % 10;
        if ((int)$cpf[$t] !== $digito) {
            return false;
        }
    }
    return true;
}

$erros = [];
// Guarda o que a pessoa digitou, para não precisar digitar tudo de novo se der erro
$v = ['nome' => '', 'usuario' => '', 'email' => '', 'cpf' => '', 'nascimento' => ''];

// Este bloco só roda quando o formulário é ENVIADO (botão Cadastrar)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v['nome']       = trim($_POST['nome-cadastro'] ?? '');
    $v['usuario']    = trim($_POST['usuario-cadastro'] ?? '');
    $v['email']      = trim($_POST['email-cadastro'] ?? '');
    $v['cpf']        = trim($_POST['cpf-cadastro'] ?? '');
    $v['nascimento'] = trim($_POST['nascimento-cadastro'] ?? '');

    $cpf        = preg_replace('/\D/', '', $v['cpf']);   // tira pontos e traço
    $senha      = $_POST['senha-cadastro'] ?? '';
    $confirmar  = $_POST['confirmar-senha'] ?? '';
    $termos     = isset($_POST['termos']);
    $promocoes  = isset($_POST['promocoes']) ? 1 : 0;
    $ofertasEsp = isset($_POST['ofertas-especificas']) ? 1 : 0;

    // ---------- Validações ----------
    if (strlen($v['nome']) < 3) {
        $erros[] = 'Informe seu nome completo.';
    }
    if (!preg_match('/^[A-Za-z0-9_.]{3,30}$/', $v['usuario'])) {
        $erros[] = 'O usuário deve ter de 3 a 30 caracteres (letras, números, ponto ou _).';
    }
    if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL)) {
        $erros[] = 'Informe um e-mail válido.';
    }
    if (!cpf_valido($cpf)) {
        $erros[] = 'CPF inválido.';
    }

    $data = DateTime::createFromFormat('Y-m-d', $v['nascimento']);
    if (!$data || $data->format('Y-m-d') !== $v['nascimento'] || $data > new DateTime('today')) {
        $erros[] = 'Informe uma data de nascimento válida.';
    }

    if (strlen($senha) < 6 || strlen($senha) > 8) {
        $erros[] = 'A senha deve ter de 6 a 8 caracteres.';
    }
    if ($senha !== $confirmar) {
        $erros[] = 'As senhas não são iguais.';
    }
    if (!$termos) {
        $erros[] = 'É preciso aceitar os termos e condições.';
    }

    // ---------- Confere se já existe alguém com os mesmos dados ----------
    if (!$erros) {
        $busca = $pdo->prepare('SELECT usuario, email, cpf FROM usuarios WHERE usuario = ? OR email = ? OR cpf = ?');
        $busca->execute([$v['usuario'], $v['email'], $cpf]);

        foreach ($busca->fetchAll() as $existente) {
            if (strcasecmp($existente['usuario'], $v['usuario']) === 0) {
                $erros[] = 'Esse usuário já está em uso.';
            }
            if (strcasecmp($existente['email'], $v['email']) === 0) {
                $erros[] = 'Esse e-mail já está cadastrado.';
            }
            if ($existente['cpf'] === $cpf) {
                $erros[] = 'Esse CPF já está cadastrado.';
            }
        }
        $erros = array_unique($erros);
    }

    // ---------- Se está tudo certo, salva no banco ----------
    if (!$erros) {
        $hash = password_hash($senha, PASSWORD_DEFAULT);   // embaralha a senha (não dá para desfazer)

        try {
            $insere = $pdo->prepare(
                'INSERT INTO usuarios
                   (nome, usuario, email, cpf, data_nascimento, senha_hash,
                    receber_promocoes, receber_ofertas_especificas)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $insere->execute([
                $v['nome'], $v['usuario'], $v['email'], $cpf,
                $v['nascimento'], $hash, $promocoes, $ofertasEsp,
            ]);

            header('Location: login.php?cadastro=ok');   // manda para o login
            exit;
        } catch (PDOException $e) {
            $erros[] = 'Não foi possível concluir o cadastro. Tente novamente.';
        }
    }
}

require __DIR__ . '/includes/header.php';
?>

  <main class="auth-page">
    <div class="container">
      <div class="auth-card">
        <h1>Cadastro</h1>
        <p>Crie sua conta e aproveite as melhores ofertas.</p>

        <?php if ($erros): ?>
          <div class="form-erros" role="alert" style="background:#fdecea;color:#b00020;border-radius:12px;padding:12px 16px;margin-bottom:16px;">
            <ul style="margin:0;padding-left:18px;">
              <?php foreach ($erros as $erro): ?>
                <li><?= htmlspecialchars($erro) ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>

        <form class="auth-form" method="post" action="cadastro.php">
          <label for="nome-cadastro">Nome completo</label>
          <input type="text" id="nome-cadastro" name="nome-cadastro" placeholder="Seu nome" value="<?= htmlspecialchars($v['nome']) ?>" required>

          <label for="usuario-cadastro">Usuário</label>
          <input type="text" id="usuario-cadastro" name="usuario-cadastro" placeholder="Escolha seu usuário" value="<?= htmlspecialchars($v['usuario']) ?>" required>

          <label for="email-cadastro">E-mail</label>
          <input type="email" id="email-cadastro" name="email-cadastro" placeholder="seu@email.com" value="<?= htmlspecialchars($v['email']) ?>" required>

          <label for="cpf-cadastro">CPF</label>
          <input type="text" id="cpf-cadastro" name="cpf-cadastro" placeholder="000.000.000-00" maxlength="14" value="<?= htmlspecialchars($v['cpf']) ?>" required>

          <label for="nascimento-cadastro">Data de nascimento</label>
          <input type="date" id="nascimento-cadastro" name="nascimento-cadastro" value="<?= htmlspecialchars($v['nascimento']) ?>" required>

          <label for="senha-cadastro">Senha</label>
          <input type="password" id="senha-cadastro" name="senha-cadastro" placeholder="De 6 a 8 caracteres" minlength="6" maxlength="8" required>

          <label for="confirmar-senha">Confirmar senha</label>
          <input type="password" id="confirmar-senha" name="confirmar-senha" placeholder="Repita a senha" minlength="6" maxlength="8" required>

          <div class="checkbox-group">
            <label class="checkbox-row">
              <input type="checkbox" name="termos" required>
              <span>Aceito os termos e condições</span>
            </label>

            <label class="checkbox-row">
              <input type="checkbox" name="promocoes">
              <span>Quero receber promoções e novidades</span>
            </label>

            <label class="checkbox-row">
              <input type="checkbox" name="ofertas-especificas">
              <span>Quero receber notificações de ofertas específicas</span>
            </label>
          </div>

          <button type="submit" class="btn btn-full">Cadastrar</button>
        </form>

        <p class="auth-footer">
          Já tem uma conta? <a href="login.php">Faça login</a>
        </p>
      </div>
    </div>
  </main>

<?php require __DIR__ . '/includes/footer.php'; ?>