/*
  ARQUIVO: favoritos.js
  FUNÇÃO: ao clicar no coração, avisa o servidor (favoritar.php) para
          salvar/remover a oferta nos favoritos do usuário logado.
  TELAS: HOME, OFERTAS e FAVORITOS.
*/

(function () {
  // Pinta ou despinta o coração
  function setFavoriteState(button, isFavorite) {
    button.classList.toggle('favoritado', isFavorite);
    button.setAttribute('aria-pressed', String(isFavorite));

    const heartPath = button.querySelector('svg path');
    if (heartPath) {
      heartPath.setAttribute('fill', isFavorite ? '#ff5722' : 'none');
    }
  }

  // Na página de favoritos, mostra a mensagem quando não sobra nenhum card
  function checkEmptyList() {
    const list = document.getElementById('lista-favoritos');
    const emptyMessage = document.getElementById('favoritos-vazio');
    if (!list || !emptyMessage) return;

    if (list.querySelectorAll('.card-oferta').length === 0) {
      emptyMessage.style.display = 'block';
    }
  }

  async function toggleFavorite(button) {
    const card = button.closest('.card-oferta');
    if (!card) return;

    button.disabled = true;

    try {
      const body = new FormData();
      body.append('oferta', card.dataset.id);

      const response = await fetch('favoritar.php', {
        method: 'POST',
        body: body,
        credentials: 'same-origin'
      });

      // 401 = não está logado: manda para o login
      if (response.status === 401) {
        window.location.href = 'login.php';
        return;
      }

      const data = await response.json();
      if (!response.ok || !data.ok) return;

      setFavoriteState(button, data.favorito);

      // Na página de favoritos, ao desfavoritar o card some
      if (!data.favorito && document.getElementById('lista-favoritos')) {
        card.remove();
        checkEmptyList();
      }
    } catch (error) {
      // Falha de rede: não muda nada na tela
    } finally {
      button.disabled = false;
    }
  }

  document.querySelectorAll('.card-oferta .btn-favorito').forEach((button) => {
    // O servidor já marca com a classe "favoritado" quem é favorito
    setFavoriteState(button, button.classList.contains('favoritado'));
    button.addEventListener('click', () => toggleFavorite(button));
  });
})();