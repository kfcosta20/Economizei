<?php
$title = 'Home';
$activePage = 'index';
$scriptFiles = ['theme.js', 'favoritos.js'];

require __DIR__ . '/config/database.php';

$sql = "SELECT o.slug, o.titulo, o.condicao, o.pagamento,
               o.preco_antigo, o.preco_novo, o.validade, o.link_oferta,
               c.slug AS categoria, l.nome AS loja
        FROM ofertas o
        JOIN categorias c ON c.id = o.categoria_id
        JOIN lojas l ON l.id = o.loja_id
        WHERE o.ativa = 1 AND o.validade >= CURDATE()
        ORDER BY o.criado_em DESC
        LIMIT 3";
$ofertas = $pdo->query($sql)->fetchAll();

require __DIR__ . '/includes/header.php';
?>
  <section class="hero">
    <div class="container hero-inner">
      <div class="hero-copy">
        <span class="section-tag">Curadoria premium</span>
        <h1>As melhores ofertas da internet, num só lugar</h1>
        <p>Encontre promoções e descontos das suas lojas favoritas todos os dias.</p>
        <div class="hero-meta">
          <span class="meta-pill">✓ Ofertas verificadas</span>
          <span class="meta-pill secondary">⚡ Atualização diária</span>
        </div>
        <a href="ofertas.php" class="btn">Ver ofertas</a>
      </div>

      <div class="hero-art" aria-hidden="true">
        <svg viewBox="0 0 420 320" role="img" aria-label="Ilustração de compras e ofertas">
          <defs>
            <linearGradient id="bagShine" x1="0" x2="1">
              <stop offset="0%" stop-color="#ffb38a"/>
              <stop offset="100%" stop-color="#ffd7b5"/>
            </linearGradient>
          </defs>
          <path d="M130 120h160c18 0 32 14 32 32v100c0 18-14 32-32 32H130c-18 0-32-14-32-32V152c0-18 14-32 32-32Z" fill="#fff4ea" stroke="#ff5722" stroke-width="4"/>
          <path d="M160 124c0-34 20-58 52-58s52 24 52 58" fill="none" stroke="#ff5722" stroke-width="4" stroke-linecap="round"/>
          <rect x="95" y="138" width="230" height="60" rx="12" fill="#ff5722" opacity="0.14"/>
          <path d="M168 180h84" stroke="#ff5722" stroke-width="6" stroke-linecap="round"/>
          <path d="M192 180v30M228 180v30" stroke="#ff5722" stroke-width="6" stroke-linecap="round"/>
          <rect x="228" y="208" width="105" height="44" rx="12" fill="url(#bagShine)" stroke="#ff5722" stroke-width="3"/>
          <path d="M252 226h58M252 238h42" stroke="#ff5722" stroke-width="4" stroke-linecap="round"/>
          <circle cx="110" cy="252" r="18" fill="#fff7f1" stroke="#ff5722" stroke-width="4"/>
          <circle cx="300" cy="84" r="26" fill="#fff7f1" stroke="#ff5722" stroke-width="4"/>
          <path d="M287 84h26M300 71v26" stroke="#ff5722" stroke-width="4" stroke-linecap="round"/>
          <path d="M105 104l34-32" stroke="#ff5722" stroke-width="4" stroke-linecap="round"/>
          <path d="M120 93l10 12" stroke="#ff5722" stroke-width="4" stroke-linecap="round"/>
          <path d="M68 196l44-26" stroke="#ff5722" stroke-width="4" stroke-linecap="round" opacity="0.75"/>
          <circle cx="56" cy="208" r="8" fill="#ff5722" opacity="0.75"/>
        </svg>
      </div>
    </div>
  </section>

  <section class="stats-bar">
    <div class="container stats-grid">
      <div class="stat-item">
        <strong>1.2k+</strong>
        <span>Ofertas ativas</span>
      </div>
      <div class="stat-item">
        <strong>24h</strong>
        <span>Atualização diária</span>
      </div>
      <div class="stat-item">
        <strong>4.9/5</strong>
        <span>Experiência do usuário</span>
      </div>
    </div>
  </section>

  <section class="categorias">
    <div class="container">
      <div class="section-heading">
        <span class="section-tag">Navegue por categoria</span>
        <h2>Categorias</h2>
      </div>
      <div class="grid-categorias">
        <a href="ofertas.php" class="card-categoria"><span class="categoria-emoji">📱</span> Eletrônicos</a>
        <a href="ofertas.php" class="card-categoria"><span class="categoria-emoji">👕</span> Moda</a>
        <a href="ofertas.php" class="card-categoria"><span class="categoria-emoji">🏠</span> Casa</a>
        <a href="ofertas.php" class="card-categoria"><span class="categoria-emoji">💄</span> Beleza</a>
        <a href="ofertas.php" class="card-categoria"><span class="categoria-emoji">🎧</span> Áudio</a>
        <a href="ofertas.php" class="card-categoria"><span class="categoria-emoji">🏃</span> Esporte</a>
        <a href="ofertas.php" class="card-categoria"><span class="categoria-emoji">🐾</span> Pet</a>
        <a href="ofertas.php" class="card-categoria"><span class="categoria-emoji">📚</span> Livros</a>
      </div>
    </div>
  </section>

  <section class="beneficios">
    <div class="container">
      <div class="section-heading center">
        <span class="section-tag">Por que escolher</span>
        <h2>Seu jeito mais inteligente de economizar</h2>
      </div>

      <div class="beneficios-grid">
        <article class="beneficio-card">
          <div class="beneficio-icon">✓</div>
          <h3>Ofertas validadas</h3>
          <p>Selecionamos promoções relevantes e com melhor custo-benefício para você.</p>
        </article>

        <article class="beneficio-card">
          <div class="beneficio-icon">⚡</div>
          <h3>Atualização diária</h3>
          <p>Você encontra novas oportunidades todos os dias sem perder tempo procurando.</p>
        </article>

        <article class="beneficio-card">
          <div class="beneficio-icon">♥</div>
          <h3>Favoritos na palma</h3>
          <p>Guarde promoções e acompanhe o que mais interessa em um só lugar.</p>
        </article>
      </div>
    </div>
  </section>

  <section class="ofertas-destaque">
    <div class="container">
      <div class="section-heading">
        <span class="section-tag">Destaques da semana</span>
        <h2>Ofertas em destaque</h2>
      </div>
      <div class="grid-ofertas">
  <?php foreach ($ofertas as $o): ?>
    <?php include __DIR__ . '/includes/card-oferta.php'; ?>
  <?php endforeach; ?>

  <?php if (empty($ofertas)): ?>
    <p>Nenhuma oferta em destaque no momento.</p>
  <?php endif; ?>
</div>
    </div>
  </section>

<?php require __DIR__ . '/includes/footer.php'; ?>
