<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Porteiro: quem não fez login é mandado para a tela de login
if (empty($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

$title = 'Perfil';
$activePage = 'perfil';
$scriptFiles = ['theme.js'];

require __DIR__ . '/config/database.php';

// Busca os dados da pessoa que está logada
$busca = $pdo->prepare(
    'SELECT nome, usuario, email, cpf, data_nascimento, receber_promocoes, receber_ofertas_especificas
     FROM usuarios WHERE id = ?'
);
$busca->execute([$_SESSION['usuario_id']]);
$usuario = $busca->fetch();

// Se a conta não existe mais, encerra a sessão
if (!$usuario) {
    header('Location: logout.php');
    exit;
}

// Quantos favoritos a pessoa tem no banco
$contagem = $pdo->prepare('SELECT COUNT(*) FROM favoritos WHERE usuario_id = ?');
$contagem->execute([$_SESSION['usuario_id']]);
$totalFavoritos = (int)$contagem->fetchColumn();

// Iniciais para o círculo do avatar (ex: "João Pereira" -> "JP")
$partes = preg_split('/\s+/', trim($usuario['nome']));
$iniciais = mb_strtoupper(mb_substr($partes[0], 0, 1));
if (count($partes) > 1) {
    $iniciais .= mb_strtoupper(mb_substr(end($partes), 0, 1));
}

// CPF escondido: mostra só os 2 últimos dígitos
$cpfMascarado = '***.***.***-' . substr($usuario['cpf'], 9, 2);

require __DIR__ . '/includes/header.php';
?>

  <main class="profile-page">
    <section class="pagina-titulo">
      <div class="container">
        <h1>Meu perfil</h1>
      </div>
    </section>

    <div class="container profile-layout">
      <aside class="profile-sidebar">
        <div class="profile-avatar"><?= htmlspecialchars($iniciais) ?></div>
        <h2><?= htmlspecialchars($usuario['nome']) ?></h2>
        <p class="profile-username">@<?= htmlspecialchars($usuario['usuario']) ?></p>
        <div class="profile-actions">
          <button type="button" class="btn btn-full">Editar perfil</button>
          <a href="logout.php" class="btn btn-outline btn-logout">Sair da conta</a>
        </div>
      </aside>

      <section class="profile-content">
        <div class="profile-card">
          <div class="premium-panel">
            <div class="premium-header">
              <h3>Resumo da conta</h3>
              <span class="premium-badge">Básico</span>
            </div>

            <div class="profile-summary">
              <div class="summary-card">
                <div class="summary-icon">♥</div>
                <strong><?= $totalFavoritos ?></strong>
                <span class="summary-label">Favoritos</span>
              </div>
              <div class="summary-card">
                <div class="summary-icon">⚡</div>
                <strong>0</strong>
                <span class="summary-label">Cupons</span>
              </div>
            </div>
          </div>

          <h3>Dados pessoais</h3>
          <div class="profile-grid">
            <div>
              <span>Nome</span>
              <p><?= htmlspecialchars($usuario['nome']) ?></p>
            </div>
            <div>
              <span>Usuário</span>
              <p><?= htmlspecialchars($usuario['usuario']) ?></p>
            </div>
            <div>
              <span>E-mail</span>
              <p><?= htmlspecialchars($usuario['email']) ?></p>
            </div>
            <div>
              <span>CPF</span>
              <p><?= htmlspecialchars($cpfMascarado) ?></p>
            </div>
            <div>
              <span>Data de nascimento</span>
              <p><?= date('d/m/Y', strtotime($usuario['data_nascimento'])) ?></p>
            </div>
          </div>
        </div>

        <div class="profile-card">
          <h3>Atividade recente</h3>
          <p>Nenhuma atividade ainda. Favorite uma oferta para ela aparecer aqui.</p>
        </div>

        <div class="profile-card">
          <h3>Preferências</h3>

          <div class="toggle-list">
            <div class="toggle-row">
              <span>Promoções e novidades</span>
              <label class="switch">
                <input type="checkbox" <?= $usuario['receber_promocoes'] ? 'checked' : '' ?>>
                <span class="slider"></span>
              </label>
            </div>

            <div class="toggle-row">
              <span>Ofertas específicas</span>
              <label class="switch">
                <input type="checkbox" <?= $usuario['receber_ofertas_especificas'] ? 'checked' : '' ?>>
                <span class="slider"></span>
              </label>
            </div>
          </div>

          <div class="plan-row">
            <div>
              <span>Plano atual</span>
              <p>Básico</p>
            </div>
            <button type="button" class="btn btn-outline small-btn">Fazer upgrade</button>
          </div>
        </div>
      </section>
    </div>
  </main>

<?php require __DIR__ . '/includes/footer.php'; ?>