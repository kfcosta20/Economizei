(function () {
  const STORAGE_KEY = 'economizeiApoieNos';
  const QR_TTL_MS = 10 * 60 * 1000;

  const methodInputs = document.querySelectorAll('input[name="payment-method"]');
  const buttons = document.querySelectorAll('.value-pill');
  const valorInput = document.getElementById('valor-apoio');
  const resumoValor = document.getElementById('valor-total');
  const resumoDoacao = document.getElementById('resumo-doacao');
  const metodoPagamento = document.getElementById('metodo-pagamento');
  const abrirQrBtn = document.getElementById('abrir-qr');
  const copiarBtn = document.getElementById('copiar-codigo');
  const copiarBtnModal = document.getElementById('copiar-codigo-modal');
  const qrcodeContainer = document.getElementById('qr-code');
  const pixCodeInput = document.getElementById('pix-code');
  const pixExpiraEm = document.getElementById('pix-expira-em');
  const modal = document.getElementById('pix-modal');
  const fecharModalBtn = document.getElementById('fechar-modal');
  const modalValor = document.getElementById('modal-valor');
  const paymentFields = document.querySelectorAll('.payment-field');
  let activePixTimerId = null;

  function clearActivePixTimer() {
    if (activePixTimerId) {
      window.clearTimeout(activePixTimerId);
      activePixTimerId = null;
    }
  }

  function formatMoney(value) {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(Math.max(Number(value || 0), 0));
  }

  function syncPaymentVisibility() {
    const choice = document.querySelector('input[name="payment-method"]:checked')?.value || 'Pix';
    const isPix = choice === 'Pix';

    paymentFields.forEach((field) => {
      field.style.display = isPix ? 'none' : 'flex';
    });

    if (!isPix) {
      if (modal) {
        modal.classList.add('hidden');
      }
    }
  }

  function updateResumen() {
    const value = Number(valorInput.value || 0);
    const formatted = formatMoney(value);

    resumoValor.textContent = formatted;
    resumoDoacao.textContent = formatMoney(value).replace('R$ ', 'R$ ');
    modalValor.textContent = formatted;

    const method = document.querySelector('input[name="payment-method"]:checked')?.value || 'Pix';
    metodoPagamento.textContent = method;
    syncPaymentVisibility();
  }

  function setSelectedValue(value) {
    const numericValue = Number(value) || 0;
    valorInput.value = numericValue;
    buttons.forEach((button) => {
      button.classList.toggle('active', Number(button.dataset.value) === numericValue);
    });
    updateResumen();
  }

  function getMaskMatrix() {
    const size = 21;
    const matrix = Array.from({ length: size }, () => Array(size).fill(0));

    const finder = (row, col) => {
      const pattern = [
        [0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],
        [1,0],[1,1],[1,2],[1,3],[1,4],[1,5],[1,6],
        [2,0],[2,1],[2,2],[2,3],[2,4],[2,5],[2,6],
        [3,0],[3,1],[3,2],[3,3],[3,4],[3,5],[3,6],
        [4,0],[4,1],[4,2],[4,3],[4,4],[4,5],[4,6],
        [5,0],[5,1],[5,2],[5,3],[5,4],[5,5],[5,6],
        [6,0],[6,1],[6,2],[6,3],[6,4],[6,5],[6,6]
      ];

      return pattern.some(([r, c]) => r === row && c === col);
    };

    for (let row = 0; row < size; row += 1) {
      for (let col = 0; col < size; col += 1) {
        if (row < 7 && col < 7) {
          matrix[row][col] = finder(row, col) ? 1 : 0;
        }
        if (row < 7 && col >= size - 7) {
          matrix[row][col] = finder(row, col - (size - 7)) ? 1 : 0;
        }
        if (row >= size - 7 && col < 7) {
          matrix[row][col] = finder(row - (size - 7), col) ? 1 : 0;
        }
      }
    }

    return matrix;
  }

  function renderQRCode(code) {
    if (!qrcodeContainer) return;

    qrcodeContainer.innerHTML = '';
    const matrix = getMaskMatrix();
    const payload = code || 'ECONOMIZEI';

    for (let index = 0; index < payload.length; index += 1) {
      const value = payload.charCodeAt(index) % 2;
      const row = 8 + (index % 7);
      const col = 8 + Math.floor(index / 7) % 7;
      matrix[row][col] = value;
    }

    matrix.forEach((row) => {
      row.forEach((cell) => {
        const cellEl = document.createElement('span');
        cellEl.className = `qr-cell ${cell ? 'active' : ''}`;
        qrcodeContainer.appendChild(cellEl);
      });
    });
  }

  function generatePixPayload(amount) {
    const uniqueKey = `${Date.now().toString(36).toUpperCase()}${Math.random().toString(36).slice(2, 12).toUpperCase()}`;
    const cents = Math.round(Number(amount || 0) * 100);
    return `00020126580014BR.GOV.BCB.PIX0136ECONOMIZEI${uniqueKey}52040000${String(cents).padStart(2, '0')}53039865480504BR5909ECONOMIZEI6009BRASILIA62070503***6304`;
  }

  function openPixModal() {
    const choice = document.querySelector('input[name="payment-method"]:checked')?.value;
    if (choice !== 'Pix') return;

    if (!modal) return;

    clearActivePixTimer();

    const amount = Number(valorInput.value || 25);
    const payload = generatePixPayload(amount);
    const expiresAt = Date.now() + QR_TTL_MS;

    localStorage.setItem(STORAGE_KEY, JSON.stringify({ payload, expiresAt }));

    renderQRCode(payload);
    pixCodeInput.value = payload;
    modalValor.textContent = formatMoney(amount);
    modal.classList.remove('hidden');
    startTimer(expiresAt);
  }

  function closePixModal() {
    if (modal) {
      modal.classList.add('hidden');
    }
  }

  function startTimer(expiresAt) {
    clearActivePixTimer();

    const update = () => {
      const remaining = Math.max(0, expiresAt - Date.now());
      const totalSeconds = Math.ceil(remaining / 1000);
      const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
      const seconds = String(totalSeconds % 60).padStart(2, '0');

      if (pixExpiraEm) {
        pixExpiraEm.textContent = `expira em ${minutes}:${seconds}`;
      }

      if (remaining <= 0) {
        pixCodeInput.value = 'QR expirado. Gere outro código para continuar.';
        qrcodeContainer.innerHTML = '';
        localStorage.removeItem(STORAGE_KEY);
        clearActivePixTimer();
        return;
      }

      activePixTimerId = window.setTimeout(update, 1000);
    };

    update();
  }

  function restorePixSession() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      if (!saved.payload || !saved.expiresAt) return;

      if (Date.now() < saved.expiresAt) {
        renderQRCode(saved.payload);
        pixCodeInput.value = saved.payload;
        modalValor.textContent = formatMoney(Number(valorInput.value || 25));
        if (pixExpiraEm) {
          startTimer(saved.expiresAt);
        }
      } else {
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch (error) {
      // ignora falha de leitura
    }
  }

  function copyCode() {
    const text = pixCodeInput.value || '';
    if (!text || text.includes('expirado')) return;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        const button = document.getElementById('copiar-codigo');
        const modalButton = document.getElementById('copiar-codigo-modal');
        if (button) button.textContent = 'Copiado';
        if (modalButton) modalButton.textContent = 'Copiado';
        setTimeout(() => {
          if (button) button.textContent = 'Copiar código';
          if (modalButton) modalButton.textContent = 'Copiar código';
        }, 1200);
      }).catch(() => {
        pixCodeInput.select();
        document.execCommand('copy');
      });
      return;
    }

    pixCodeInput.select();
    document.execCommand('copy');
  }

  methodInputs.forEach((input) => {
    input.addEventListener('change', () => {
      updateResumen();
    });
  });

  buttons.forEach((button) => {
    button.addEventListener('click', () => {
      setSelectedValue(button.dataset.value);
    });
  });

  valorInput.addEventListener('input', () => {
    buttons.forEach((button) => {
      const match = Number(button.dataset.value) === Number(valorInput.value);
      button.classList.toggle('active', match);
    });
    updateResumen();
  });

  abrirQrBtn.addEventListener('click', openPixModal);
  copiarBtn.addEventListener('click', copyCode);
  copiarBtnModal.addEventListener('click', copyCode);
  fecharModalBtn.addEventListener('click', closePixModal);

  if (modal) {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closePixModal();
    });
  }

  updateResumen();
})();
