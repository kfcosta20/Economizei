<?php
// Garante que a sessão esteja iniciada para saber se há alguém logado
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$activePage = $activePage ?? 'index';
$logado = !empty($_SESSION['usuario_id']);

// Links que todo mundo vê
$navItems = [
    ['page' => 'index',     'href' => 'index.php',     'label' => 'Início'],
    ['page' => 'ofertas',   'href' => 'ofertas.php',   'label' => 'Ofertas'],
    ['page' => 'apoie-nos', 'href' => 'apoie-nos.php', 'label' => 'Apoie-nos'],
    ['page' => 'contato',   'href' => 'contato.php',   'label' => 'Contato'],
];

// Links só de quem está logado
if ($logado) {
    $navItems[] = ['page' => 'perfil',    'href' => 'perfil.php',    'label' => 'Perfil'];
    $navItems[] = ['page' => 'favoritos', 'href' => 'favoritos.php', 'label' => 'Favoritos'];
}

// Links do final do menu (depois do botão de tema)
if ($logado) {
    $navFinal = [
        ['page' => 'sair', 'href' => 'logout.php', 'label' => 'Sair'],
    ];
} else {
    $navFinal = [
        ['page' => 'login',    'href' => 'login.php',    'label' => 'Entrar'],
        ['page' => 'cadastro', 'href' => 'cadastro.php', 'label' => 'Cadastrar'],
    ];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($title ?? 'ECONOMIZEI'); ?></title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="header">
    <div class="container header-content">
      <a href="index.php" class="logo">ECONOMIZEI</a>
      <nav class="nav">
        <ul>
          <?php foreach ($navItems as $item): ?>
            <li<?= $activePage === $item['page'] ? ' class="active"' : ''; ?>>
              <a href="<?= $item['href']; ?>"><?= $item['label']; ?></a>
            </li>
          <?php endforeach; ?>
          <li class="theme-toggle-item">
            <button type="button" class="theme-toggle" aria-label="Ativar modo escuro" aria-pressed="false">
              <span class="theme-icon" aria-hidden="true"></span>
            </button>
          </li>
          <?php foreach ($navFinal as $item): ?>
            <li<?= $activePage === $item['page'] ? ' class="active"' : ''; ?>>
              <a href="<?= $item['href']; ?>"><?= $item['label']; ?></a>
            </li>
          <?php endforeach; ?>
        </ul>
      </nav>
    </div>
  </header>