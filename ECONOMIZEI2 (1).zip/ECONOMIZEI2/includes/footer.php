  <footer class="footer">
    <div class="container footer-grid">
      <div class="footer-brand">
        <h3>ECONOMIZEI</h3>
        <p>As melhores ofertas e descontos, todos os dias.</p>
      </div>

      <div class="footer-links">
        <h4>Links rápidos</h4>
        <ul>
          <li><a href="index.php">Início</a></li>
          <li><a href="ofertas.php">Ofertas</a></li>
          <li><a href="contato.php">Contato</a></li>
        </ul>
      </div>

      <div class="footer-social">
        <h4>Redes sociais</h4>
        <div class="social-icons">
          <a href="#" aria-label="Instagram" class="social-icon">
            <svg viewBox="0 0 24 24"><rect x="3.5" y="3.5" width="17" height="17" rx="4" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="17.2" cy="6.8" r="1.2" fill="currentColor"/></svg>
          </a>
          <a href="#" aria-label="WhatsApp" class="social-icon">
            <svg viewBox="0 0 24 24"><path d="M7 17.5 4.5 19.5v-3.4A8.5 8.5 0 1 1 19.5 12a8.5 8.5 0 0 1-12.5 5.5Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.2 8.8c.4-.5 1-.9 1.6-.9.4 0 .8.2 1 .5l.5.8c.2.3.1.8-.1 1l-.4.6c-.2.3-.2.7.1 1l.7.8c.3.3.8.3 1.1.1l.7-.5c.2-.2.5-.3.8-.2.4.1.7.4.8.8.3 1.1-.2 2.1-1.2 2.8-1.1.8-2.7 1-4.2.4-2.4-1-4.1-3.3-4.2-5.8-.1-1 .3-2 1.1-2.7.4-.3.8-.4 1.2-.4Z" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </a>
          <a href="#" aria-label="Facebook" class="social-icon">
            <svg viewBox="0 0 24 24"><path d="M14 8h2V4.5h-2.5A3.5 3.5 0 0 0 10 8v2H8v3.5h2V20h3.5v-6.5h2.3L16 10h-2.5V8.8c0-.5.4-.8.9-.8Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </a>
        </div>
      </div>
    </div>

    <div class="container footer-bottom">
      <p>&copy; 2026 ECONOMIZEI. Projeto acadêmico.</p>
    </div>
  </footer>

  <?php if (!empty($scriptFiles)): ?>
    <?php foreach ($scriptFiles as $script): ?>
      <script src="<?= htmlspecialchars($script); ?>"></script>
    <?php endforeach; ?>
  <?php endif; ?>
</body>
</html>
