<?php
/*
  ARQUIVO: includes/card-oferta.php
  FUNÇÃO: desenha UM card de oferta. Recebe a variável $o (uma linha do banco).
  USO: dentro de um foreach, escreva:
      include __DIR__ . '/includes/card-oferta.php';
*/

// Calcula o desconto em % a partir dos preços
$desconto = $o['preco_antigo'] > 0
    ? round((1 - $o['preco_novo'] / $o['preco_antigo']) * 100)
    : 0;
?>
<div class="card-oferta"
     data-id="<?= htmlspecialchars($o['slug']) ?>"
     data-categoria="<?= htmlspecialchars($o['categoria']) ?>"
     data-pagamento="<?= htmlspecialchars(strtolower($o['pagamento'])) ?>">

  <button type="button" class="btn-favorito" aria-label="Favoritar oferta">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.7 4.8 13.8A4.3 4.3 0 0 1 12 7.2a4.3 4.3 0 0 1 7.2 6.6L12 20.7Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
  </button>

  <span class="tag">-<?= $desconto ?>%</span>
  <h3><?= htmlspecialchars($o['titulo']) ?></h3>

  <div class="card-icon" aria-hidden="true">
    <svg viewBox="0 0 24 24"><path d="M7 9V7a5 5 0 0 1 10 0v2M6 9h12l-1 10H7L6 9Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
  </div>

  <p class="loja"><?= htmlspecialchars($o['loja']) ?></p>
  <p class="condicao"><?= htmlspecialchars($o['condicao'] ?? '') ?></p>
  <p class="meta-oferta"><span>Pagamento:</span> <?= htmlspecialchars($o['pagamento']) ?></p>
  <p class="preco-antigo">R$ <?= number_format($o['preco_antigo'], 2, ',', '.') ?></p>
  <p class="preco-novo">R$ <?= number_format($o['preco_novo'], 2, ',', '.') ?></p>

  <p class="validade">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3.5v2M17 3.5v2M4.5 9.5h15M5 6.5h14a1.5 1.5 0 0 1 1.5 1.5v9A1.5 1.5 0 0 1 19 18.5H5A1.5 1.5 0 0 1 3.5 17V8A1.5 1.5 0 0 1 5 6.5Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
    <span>Válido até <?= date('d/m', strtotime($o['validade'])) ?></span>
  </p>

  <a href="<?= htmlspecialchars($o['link_oferta'] ?: '#') ?>" class="btn-outline">Ver oferta</a>
</div>